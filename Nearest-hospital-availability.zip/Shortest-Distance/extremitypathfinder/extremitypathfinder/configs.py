DEFAULT_PICKLE_NAME = "environment.pickle"

# command line interface
# json data input format:
BOUNDARY_JSON_KEY = "boundary"
HOLES_JSON_KEY = "holes"
